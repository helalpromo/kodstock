package com.helalpromo.kodstock

import android.app.Activity
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.graphics.Bitmap
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.JavascriptInterface
import android.provider.MediaStore
import android.content.ContentValues
import android.util.Base64
import java.io.OutputStream
import android.content.Context

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 701

    companion object {
        private const val START_URL = "https://helalpromo.github.io/kodstock/"
        private const val APP_HOST = "helalpromo.github.io"
        private const val APP_PATH_PREFIX = "/kodstock"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)

        webView.addJavascriptInterface(CsvDownloadBridge(), "KodStockDownloads")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return routeUrl(request.url)
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return routeUrl(Uri.parse(url))
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                installBlobDownloadHandler(view)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                return try {
                    val intent = fileChooserParams.createIntent()
                    startActivityForResult(intent, fileChooserRequestCode)
                    true
                } catch (e: ActivityNotFoundException) {
                    this@MainActivity.filePathCallback = null
                    Toast.makeText(this@MainActivity, "No file picker available", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }

        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                Toast.makeText(this, "Preparing file download…", Toast.LENGTH_SHORT).show()
                return@DownloadListener
            }
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .setTitle("KodStock download")
                    .setDescription("Downloading file")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeFileName(contentDisposition, url))
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(false)
                if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
                val cookie = CookieManager.getInstance().getCookie(url)
                if (!cookie.isNullOrBlank()) request.addRequestHeader("Cookie", cookie)
                val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                manager.enqueue(request)
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Could not start download", Toast.LENGTH_LONG).show()
            }
        })

        if (savedInstanceState == null) {
            webView.loadUrl(START_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }


    private fun installBlobDownloadHandler(view: WebView) {
        val script = """
            (function() {
              if (window.__kodstockBlobDownloadInstalled) return;
              window.__kodstockBlobDownloadInstalled = true;
              document.addEventListener('click', function(event) {
                var a = event.target && event.target.closest ? event.target.closest('a[download]') : null;
                if (!a || !a.href || !a.href.startsWith('blob:')) return;
                event.preventDefault();
                event.stopPropagation();
                fetch(a.href).then(function(r) { return r.blob(); }).then(function(blob) {
                  var reader = new FileReader();
                  reader.onloadend = function() {
                    var result = String(reader.result || '');
                    var comma = result.indexOf(',');
                    if (comma >= 0 && window.KodStockDownloads) {
                      window.KodStockDownloads.saveBase64(a.download || 'kodstock-export.csv', blob.type || 'text/csv', result.substring(comma + 1));
                    }
                  };
                  reader.readAsDataURL(blob);
                }).catch(function() {
                  if (window.KodStockDownloads) window.KodStockDownloads.reportFailure('Could not prepare CSV export');
                });
              }, true);
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    inner class CsvDownloadBridge {
        @JavascriptInterface
        fun saveBase64(fileName: String, mimeType: String, base64Data: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "kodstock-export.csv" }
                    val mime = mimeType.ifBlank { "text/csv" }
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Could not create download file")
                    contentResolver.openOutputStream(uri).use { output ->
                        (output ?: throw IllegalStateException("Could not open download file")).write(bytes)
                    }
                    Toast.makeText(this@MainActivity, "CSV saved to Downloads", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "CSV export failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun reportFailure(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show() }
        }
    }

    private fun routeUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase()
        if (scheme == "http" || scheme == "https") {
            val isInsideApp = uri.scheme == "https" &&
                uri.host == APP_HOST &&
                (uri.path == APP_PATH_PREFIX || uri.path?.startsWith("$APP_PATH_PREFIX/") == true)

            if (isInsideApp) return false

            // Do not allow insecure HTTP pages inside the app.
            if (scheme == "http") {
                Toast.makeText(this, "Insecure HTTP link blocked", Toast.LENGTH_SHORT).show()
                return true
            }

            return try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            } catch (e: ActivityNotFoundException) {
                true
            }
        }

        // Handle mailto:, tel:, intent:, etc. outside WebView.
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (e: Exception) {
            true
        }
    }

    private fun safeFileName(contentDisposition: String?, url: String): String {
        val fromHeader = contentDisposition
            ?.substringAfter("filename=", "")
            ?.trim()
            ?.trim('"')
            ?.takeIf { it.isNotBlank() }
        val fromUrl = Uri.parse(url).lastPathSegment?.takeIf { it.isNotBlank() }
        val candidate = (fromHeader ?: fromUrl ?: "kodstock-download")
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
        return candidate.take(120).ifBlank { "kodstock-download" }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback
            filePathCallback = null
            callback?.onReceiveValue(
                if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                else null
            )
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.destroy()
        }
        super.onDestroy()
    }
}
