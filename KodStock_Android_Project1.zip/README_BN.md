# KodStock Android APK — সেটআপ নির্দেশিকা

এই প্যাকেজটি `https://helalpromo.github.io/kodstock/` ওয়েব অ্যাপকে Android WebView অ্যাপ হিসেবে চালানোর জন্য তৈরি।

## কী থাকবে
- KodStock নামের Android অ্যাপ
- বিদ্যমান ওয়েব অ্যাপ URL লোড করবে
- JavaScript ও DOM/local storage চালু
- Back বাটনে আগের পেজে ফেরা
- ওয়েব ফর্মে ফাইল বেছে আপলোড করার সুবিধা
- HTTPS ডাউনলোড Android Downloads-এ সংরক্ষণ
- শুধু KodStock-এর নির্দিষ্ট path অ্যাপের ভিতরে; বাইরের লিংক ব্রাউজারে খোলে
- GitHub Actions দিয়ে APK build করার workflow

## সহজতম পদ্ধতি: GitHub দিয়ে APK বানানো
1. ZIP ফাইলটি Extract করুন।
2. Extract করা ফোল্ডারের `android-app` ফোল্ডারটি আপনার `helalpromo/kodstock` repository-তে আপলোড করুন।
3. `.github/workflows/build-kodstock-apk.yml` ফাইলটি আপনার repository-র একই path-এ কপি করুন।
   - আগে থেকে `.github/workflows` না থাকলে নতুন করে তৈরি করুন।
   - আপনার বর্তমান `index.html` বা ওয়েব অ্যাপ ফাইল মুছবেন/প্রতিস্থাপন করবেন না।
4. GitHub-এ commit/push করুন।
5. Repository → **Actions** → **Build KodStock Android APK** খুলুন।
6. Workflow শেষ হলে run-এর **Artifacts** অংশ থেকে `KodStock-debug-apk` ডাউনলোড করুন।
7. ZIP artifact extract করে `app-debug.apk` ফোনে পাঠান।
8. Android ফোনে APK খুলুন। প্রয়োজন হলে Settings-এ ওই source থেকে install করার অনুমতি দিন।

## নিজের কম্পিউটারে Android Studio দিয়ে build
1. Android Studio ইনস্টল করুন এবং Android SDK Platform 35 ও JDK 17 নিশ্চিত করুন।
2. `android-app` ফোল্ডারটি Android Studio-তে project হিসেবে খুলুন।
3. Gradle sync শেষ হলে **Build → Build APK(s)** নির্বাচন করুন।
4. APK সাধারণত `android-app/app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।
   - এই প্যাকেজে Gradle wrapper JAR অন্তর্ভুক্ত নেই; Android Studio-তে local Gradle সেটআপ প্রয়োজন হতে পারে। GitHub Actions পদ্ধতিটি সহজ।

## গুরুত্বপূর্ণ সীমাবদ্ধতা ও পরীক্ষা
- এটি WebView wrapper; মূল ওয়েব অ্যাপের ডেটাবেস/লজিক নতুন করে তৈরি করে না।
- অ্যাপটি ইন্টারনেট ছাড়া আপনার অনলাইন GitHub Pages ওয়েব অ্যাপ চালাতে পারবে না।
- Android WebView-এর localStorage/cookies, Chrome browser-এর storage থেকে আলাদা। আপনার ওয়েব অ্যাপ যদি পণ্য/লেনদেন শুধু browser localStorage-এ রাখে, Chrome-এর পুরোনো ডেটা APK-তে নিজে থেকে আসবে না। আগে test data দিয়ে পরীক্ষা করুন এবং ডেটা export/backup রাখুন।
- Login, invoice print/PDF, file upload/download, refresh এবং Android Back button পরীক্ষা করুন। Print/PDF feature যদি browser-specific API-এর ওপর নির্ভর করে, অতিরিক্ত Android print integration লাগতে পারে।
- এই প্রথম সংস্করণে camera/microphone permission বা push notification যোগ করা হয়নি।
- শুধু নিজের/অনুমোদিত ওয়েব অ্যাপ ব্যবহার করুন। Login credentials source code-এ রাখবেন না।

## URL পরিবর্তন
`app/src/main/java/com/helalpromo/kodstock/MainActivity.kt` ফাইলে `START_URL` এবং `APP_HOST`/`APP_PATH_PREFIX` নির্ধারিত আছে।
